# NeoFlyTouristTour
Add your favorite POV as tourist mission into NeoFly

## How to use
* First ensure the path to your NeoFlyDatabase is correct in the NeoFlyTouristTour.ini file
![](NeoFlyTouristPOI1.gif)
![](NeoFlyTouristPOI2.gif)

## Issues
If you face a "script error" message while clicking on load position it's because the bing map wasn't fully loaded before you clicked, click yes and wait a bit more. 
Please after launching the application, wait several seconds the web page have fully loaded.
<br/>
<br/>

## If you like my work :)
[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=G3F8XX7KXN6QQ)
